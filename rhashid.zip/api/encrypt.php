<?php
include ("../databases/connection.php");

$text = $_GET["text"];
$type = $_GET["type"];
$out = array();
if ($type == "md5"){
	if ($text){
		$result = md5($text);
		mysqli_query($db, "INSERT INTO wordlist VALUES (NULL, '$text')");
		$out["error"] = false;
		$out["result"]["text"] = $text;
		$out["result"]["hash"] = $result;
	}else{
		$out["error"] = true;
		$out["message"] = "Please input text";
	}
}elseif ($type == "sha1"){
	if ($text){
		$result = sha1($text);
		mysqli_query($db, "INSERT INTO wordlist VALUES (NULL, '$text')");
		$out["error"] = false;
		$out["result"]["text"] = $text;
		$out["result"]["hash"] = $result;
	}else{
		$out["error"] = true;
		$out["message"] = "Please input text";
	}
}elseif ($type == "sha512"){
	if ($text){
		$result = hash($type, $text);
		mysqli_query($db, "INSERT INTO wordlist VALUES (NULL, '$text')");
		$out["error"] = false;
		$out["result"]["text"] = $text;
		$out["result"]["hash"] = $result;
	}else{
		$out["error"] = true;
		$out["message"] = "Please input text";
	}
}elseif($type == "whirlpool"){
	if ($text){
		$result = hash($type, $text);
		mysqli_query($db, "INSERT INTO wordlist VALUES (NULL, '$text')");
		$out["error"] = false;
		$out["result"]["text"] = $text;
		$out["result"]["hash"] = $result;
	}else{
		$out["error"] = true;
		$out["message"] = "Please input hash";
	}
}else{
	$out["error"] = true;
	$out["message"] = "Type not supported";
}

echo json_encode($out, TRUE);
?>
