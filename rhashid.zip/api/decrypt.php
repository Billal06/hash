<?php
include ("../databases/connection.php");

function sha512($text){
	return hash("sha512", $text);
}

$hstr = $_GET["hash"];
$type = $_GET["type"];

$out = array();

$f = 0;

$s = mysqli_query($db, "SELECT * FROM wordlist");
if ($type == "md5"){
	if ($hstr){
		while ($data = mysqli_fetch_array($s)){
			if (md5($data["value"]) == $hstr){
				$f +=1 ;
				$out["error"] = false;
				$out["result"]["hash"] = $hstr;
				$out["result"]["text"] = $data["value"];
				break;
			}
		}
		if ($f == 0){
			$out["error"] = true;
			$out["message"] = "The hash is not in the database";
		}
	}else{
		$out["error"] = true;
		$out["message"] = "Please input hash";
	}
}elseif ($type == "sha1"){
	if ($hstr){
		while ($data = mysqli_fetch_array($s)){
			if (sha1($data["value"]) == $hstr){
				$f +=1 ;
				$out["error"] = false;
				$out["result"]["hash"] = $hstr;
				$out["result"]["text"] = $data["value"];
				break;
			}
		}
		if ($f == 0){
			$out["error"] = true;
			$out["message"] = "The hash is not in the database";
		}
	}else{
		$out["error"] = true;
		$out["message"] = "Please input hash";
	}
}elseif ($type == "sha512"){
	if ($hstr){
		while ($data = mysqli_fetch_array($s)){
			if (hash("sha512", $data["value"]) == $hstr){
				$f += 1;
				$out["error"] = false;
				$out["result"]["hash"] = $hstr;
				$out["result"]["text"] = $data["value"];
				break;
			}
		}
		if ($f == 0){
			$out["error"] = true;
			$out["message"] = "The hash is not in the database";
		}
	}else{
		$out["error"] = true;
		$out["message"] = "Please input hash";
	}
}elseif($type == "whirlpool"){
	if ($hstr){
		while ($data = mysqli_fetch_array($s)){
			if (hash("whirlpool", $data["value"]) == $hstr){
				$f += 1;
				$out["error"] = false;
				$out["result"]["hash"] = $hstr;
				$out["result"]["text"] = $data["value"];
				break;
			}
		}
		if ($f == 0){
			$out["error"] = true;
			$out["message"] = "The hash is not in the database";
		}
	}else{
		$out["error"] = true;
		$out["message"] = "Please input hash";
	}
}else{
	$out["error"] = true;
	$out["message"] = "Type not found";
}

echo json_encode($out, TRUE);	
?>
